/*
Majazz H. Allah 
1321L WE1
Term: Summer 2022
Professor Howard
TA Maneesha Kumari Penmetsa

Lab#:Assignment 3B

*/

#include <iostream>
using namespace std; 
int main() {

char day; // day of week in capital letters
char time; // a or p tell the user if its afternoon or morning

cout << "What day of the week is it? ";
cin >> day;
  
cout << "What time of day? ";
cin >> time;


switch (time) { // switch container start
  case 'a': // AM Check

 switch (day) {

    case 'M':
    cout << "On Monday Morning, you’ll be holding office hours!";
  
    break;

    case 'T':
    cout << "On Tuesday Morning, you’ll be holding office hours!";
;
    break;
      
    case 'W':
    cout << "On Wednesday Morning, you’ll have some free time!";
  
    break;
  
    case 'R':
    cout << "On Thursday Morning, you’ll be teaching C++, section     WE3!";
    break;

    case 'F':
    cout << "On Friday Morning, you’ll be holding office hours!";
    break;  

    case 'S':

    cout << "not a a valid day or time";
        
    break; 

    case 'U':

      cout << "not a a valid day or time";

    break;
   }
    
  break; // end of AM check
   


  case 'p': // PM Check

    switch (day) {

    case 'M':
    cout << "On Monday Afternoon, you’ll be holding office hours!";
  
    break;

    case 'T':
     cout << "On Tuesday Afternoon, you’ll be holding office hours!";
    break;
      
    case 'W':
    cout << "On Wednesday Afternoon, you’ll have some free time!";
    break;
  
    case 'R':
    cout << "On Thursday Afternoon, you’ll be teaching C++, section WE3!";
    break;

    case 'F':
    cout << "On Friday Afternoon, you’ll be holding office hours!";
    break;
    
    case 'S':
    cout << "not a a valid day or time";    
    break; 

    case 'U':
    cout << "not a a valid day or time";
    break;
    } 
 break; // end of PM check
  } // switch container end

} // end of main
  
