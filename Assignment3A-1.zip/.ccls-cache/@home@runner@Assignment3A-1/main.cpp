/*
Majazz H. Allah 
1321L WE1
Term: Summer 2022
Professor Howard
TA Maneesha Kumari Penmetsa

Lab#:Assignment 3A

*/

#include <iostream>
#include <cmath>

using namespace std;

int main() {
float bag = .1;
float hat = .25;
float shirt = .5;
float bottle = .75;
float hoodie = 1;
float event;
string str;

cout << "How many events have you attended? "; 
cin >> event;  
  

if (event < 63 && event > 0) // event completion check start
{


 // event percentage formula
  
  float eventPercent = (event/63)*100;
 

  
  // check for event completion between 10% - 25%
  if (eventPercent/100 < hat && eventPercent/100 >= bag)
  {
    cout << "you've been to " << round(eventPercent) << "% of all SBL events!" << endl;

  cout << "You’ve earned a Drawstring Bag!" << endl;

  }

  // check for event completion between 25% - 49%
  if (eventPercent/100 >= hat && eventPercent/100 < shirt)
  {
    cout << "you've been to " << round(eventPercent) << "% of all SBL events!" << endl;

  cout << "You’ve earned a Drawstring Bag!" << endl;
cout << "You’ve earned a hat!" << endl;
  }

  // check for event completion between 50% - 74%
  if (eventPercent/100 >= shirt && eventPercent/100 < bottle)
  {
    cout << "you've been to " << round(eventPercent) << "% of all SBL events!" << endl;

  cout << "You’ve earned a Drawstring Bag!" << endl;
cout << "You’ve earned a hat!" << endl;
cout << "You’ve earned a T-Shirt!"
 << endl;
  }
  
  // check for event completion between 75% - 99%
  if (eventPercent/100 >= bottle && eventPercent/100 < hoodie)
  {
    cout << "you've been to " << round(eventPercent) << "% of all SBL events!" << endl;

  cout << "You’ve earned a Drawstring Bag!" << endl;
cout << "You’ve earned a hat!" << endl;
cout << "You’ve earned a T-Shirt!"
 << endl;
cout << "You've earned a Glass Water Bottle!"
 << endl;   
  }
  
  } // end of event completion check

// check for event completion between 0% - 9%
  if (event ==0)
  {
    cout << "Check out events at https://studentaffairs.kennesaw.edu/scrappysbucketlist/ !";
  }    

 

  

{
  

}



 // check for complete event participation (100%)
if (event/63 == hoodie)
  {
    //earn everything 
    // ask if they are graduating
    // if not, special reward
    // if they are, they gain a challenge coin and graduation cords
   float eventPercent = hoodie*100;

       cout << "you've been to " << round(eventPercent) << "% of all SBL events! \n";

cout << "You’ve earned a Drawstring Bag! \n";
cout << "You’ve earned a hat! \n";
cout << "You’ve earned a T-Shirt!\n";
cout << "You've earned a Glass Water Bottle!\n";
cout << "You've earned a Hoodie! \n";



   //graduation ask start
    cin.ignore(1,'\n');
  cout << "Are you graduating?";
  getline(cin, str);  
  
  if (str.compare ("Yes") == 0)
  {
    
    cout << "You've earned a Challenge Coin and Graduation Cords";
  }
    else {
      cout << " there's a special reward when you graduate!";
    }
 // graduation ask end







    
  } // end of 100% check



  
 



  

  } // end of main