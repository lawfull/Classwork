/*
Majazz H. Allah 
1321L WE1
Term: Summer 2022
Professor Howard
TA Maneesha Kumari Penmetsa

Lab#:Lab 4B

*/

#include <iostream>
#include <cmath>
using namespace std;
float num;
float num2;
int menuChoice;
int main() {

cout << "Welcome! \n Please input a number: ";
  cin >> num;
  
cout << "What would you like to do to this number: \n" << " 0- Get the additive inverse of the number " << "\n 1- Get the reciprocal of the number" << "\n 2- Square the number" << "\n 3- Cube the number " << "\n 4- Exit the program \n \n";
  cin >> menuChoice;
  
  switch (menuChoice)
    {
      case 0:
      num2 = num*-1;
      cout << "\n The additive inverse of " << num << " is " << num2;
      break;
      
      case 1:
      num2 = 1/num;
      cout << "\n The reciprocal of " << num << " is " << num2;
      break;

      case 2:
      num2 = num*num;
      cout << "\n The square of " << num << " is " << num2;
      break;

      case 3:
      num2 = num*num*num;
      cout << "\n The cube of " << num << " is " << num2;
      break;

      case 4:
      
      cout << "\n Thank you, goodbye! ";
      break;

      default:
      cout << "\n Invalid input, please try again!";
      break;
      
    }


  
}