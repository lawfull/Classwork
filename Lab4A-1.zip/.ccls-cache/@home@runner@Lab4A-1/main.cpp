/*
Majazz H. Allah 
1321L WE1
Term: Summer 2022
Professor Howard
TA Maneesha Kumari Penmetsa

Lab#:Lab 4A

*/

#include <iostream>
#include <cmath>
using namespace std;
float grade; 
int main() {

  cout << "Enter the score of your exam:";
  cin >> grade;

  grade = round(grade);
  
  if (grade > 64) //grade check
  {
    if (grade <= 65)
    {
      cout << "Letter Grade is: A";
    }

    if (grade <= 70 && grade>= 65)
    {
      cout << "Letter Grade is: D";
    }
    
    if (grade <= 73 && grade>= 71)
    {
      cout << "Letter Grade is: D+";
    }

    if (grade <= 76 && grade>= 74)
    {
      cout << "Letter Grade is: C";
    }

    if (grade <= 79 && grade>= 77)
    {
      cout << "Letter Grade is: C-";
    }

    if (grade <= 82 && grade>= 80)
    {
      cout << "Letter Grade is: C+";
    }

    if (grade <= 85 && grade>= 83)
    {
      cout << "Letter Grade is: B-";
    }

    if (grade <= 88 && grade>= 86)
    {
      cout << "Letter Grade is: B";
    }

    if (grade <= 91 && grade>= 89)
    {
      cout << "Letter Grade is: B+";
    }

    if (grade <= 94 && grade>= 92)
    {
      cout << "Letter Grade is: A-";
    }

    if (grade <= 97 && grade>= 95)
    {
      cout << "Letter Grade is: A";
    }

    if ( grade >= 98 || grade == 100)
    {
      cout << "Letter Grade is: A+";
    }

    
  }
  else {
    cout << "Letter Grade is: F";
  }













  
} //end of main