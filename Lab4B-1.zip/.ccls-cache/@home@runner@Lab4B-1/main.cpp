/*
Majazz H. Allah 
1321L WE1
Term: Summer 2022
Professor Howard
TA Maneesha Kumari Penmetsa

Lab#:Lab 4B

*/

#include <iostream>
#include <cmath>
using namespace std;
string week;

int main() {

cout << "Enter the day: ";
getline(cin, week);

if (week.compare("Monday")==0 || week.compare("monday")==0)
{
  cout << "I have class today!";
}
  else if (week.compare("Wendsday")==0 || week.compare("wendsday")==0)
  {
    cout << "I have class today!";
  }
  else if (week.compare("Friday")==0 || week.compare("friday")==0)
  {
    cout << "It’s Friday! Friday! Gotta get down on Friday!";
  }
  else {
    cout << "I should use this time to do my homework. ";
  }
  







  
}