/*
Majazz H. Allah 
1321L WE1
Term: Summer 2022
Professor Howard
TA Maneesha Kumari Penmetsa

Lab#:Assignment 3C

*/


#include <iostream>
using namespace std;
string device; // device user input
float version; // numbered version of device software
string tech; // use this for NFC / Bluetooth check

int main() {

cout << "What mobile device do you have? "; 
getline(cin, device);

//is your device Apple or Android?
if (device.compare("Apple") == 0 || device.compare("Android") == 0)
{
  cout << "What version do you have? ";
  cin >> version;

  //android check start
  if (version >= 10 && device.compare("Android")==0)
  {
    cout << "Congratulations, you can run the app!";
    
  }
  else if (version < 10 && device.compare("Android")==0) // if version < 10, does it support NFC?
  {
    cout << "Does your device support Bluetooth connections? ";
    cin.ignore(1,'\n'); // cleans up cin buffer when you need more than one input, thanks Carter!
    getline(cin, tech);
    if (tech.compare("Yes") == 0)
    {
      cout << "Congratulations, you can run the app!";
    }
    else {
      cout << "I’m sorry, our app does not support your device.";
    }

    
    
  
  } // bluetooth check end

  //apple check start
  if (version >= 14 && device.compare("Apple")==0)
  {
    cout << "Congratulations, you can run the app!";
    
  }
  else if (version < 14 && device.compare("Apple")==0) // if version < 14, does it support NFC?
  {
    cout << "Does your device support NFC? ";
    cin.ignore(1,'\n');
    getline(cin, tech);
    if (tech.compare("Yes") == 0)
    {
      cout << "Congratulations, you can run the app!";
    }
    else {
      cout << "I’m sorry, our app does not support your device.";
    }
    
  
  } // nfc check end


  
  
}
  else {
  cout << "I'm sorry";
  }
  




  








  
} // end of main